from setuptools import setup

setup(
    name='parking_env',
    version='0.0.1',
    install_requires=['gym', 'numpy', 'pybullet', 'stable-baselines3', 'torch', 'moviepy']
)
