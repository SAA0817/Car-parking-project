# https://docs.python-requests.org/zh_CN/latest/

import requests
import time


def turn(action):

    global steering_angle
    steering_angle = 0

    if action == 0:  # 前进
        r = requests.post('http://192.168.31.194/motor_control?speed=60')
        r = requests.post('http://192.168.31.194/servo_control?angle='+str(steering_angle))

    elif action == 1:  # 后退
        r = requests.post('http://192.168.31.194/motor_control?speed=-60')
        r = requests.post('http://192.168.31.194/servo_control?angle='+str(steering_angle))
    
    elif action == 2:  # 左转
        if steering_angle > -45:
            steering_angle -= 9
        r = requests.post('http://192.168.31.194/motor_control?speed=60')
        r = requests.post('http://192.168.31.194/servo_control?angle='+str(steering_angle))
        
    elif action == 3:  # 右转
        if steering_angle < 45:
            steering_angle += 9
        r = requests.post('http://192.168.31.194/motor_control?speed=60')
        r = requests.post('http://192.168.31.194/servo_control?angle='+str(steering_angle))
        
    elif action == 4:  # 停止
        r = requests.post('http://192.168.31.194/motor_control?speed=0')
        r = requests.post('http://192.168.31.194/servo_control?angle=0'+str(steering_angle))
        

    

    




